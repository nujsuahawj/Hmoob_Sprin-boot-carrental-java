package io.javabrains.coronavirustracker.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import io.javabrains.coronavirustracker.services.CoronaVirusDataService;

@Controller
public class BlogCt {
                    @Autowired
                    CoronaVirusDataService coronaVirusDataService;
                    @GetMapping("/blog")
                    public String home(Model model) {
                        return "blog";}
                    
}
